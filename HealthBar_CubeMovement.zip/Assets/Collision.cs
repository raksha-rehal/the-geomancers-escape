using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Collision : MonoBehaviour
{
    public Vector3 rotationAngle;
    public GameObject teleportPoint;

    void OnTriggerEnter(Collider player)
    {
        player.transform.rotation = Quaternion.Euler(rotationAngle);
        player.transform.position = teleportPoint.transform.position;
    }
}
