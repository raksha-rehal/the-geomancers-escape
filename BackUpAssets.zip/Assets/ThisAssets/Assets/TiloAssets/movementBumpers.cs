using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class movementBumpers : MonoBehaviour
{
    public GameObject right;
    public GameObject left;
    public GameObject up;
    public GameObject down;
    public bool rightClear;
    public bool leftClear;
    public bool upClear;
    public bool downClear;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
