using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Toungue : MonoBehaviour
{
    public Animator animator; 
    // Start is called before the first frame update
    void Start()
    {
    }

    // Update is called once per frame
    public void Attack(){
        animator.Play("BossTounge");
    }
   public void StopSS(){
        animator.Play("New State");
   }
}
