using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallCollision : MonoBehaviour
{
    public Vector3 rotationAngle;
    public GameObject teleportPoint;
    public GameObject floor;

    void OnTriggerEnter(Collider other)
    {
        Debug.Log(other.gameObject.name);

        if(other.gameObject.name == "Player"){
            other.transform.position = teleportPoint.transform.position;
            other.transform.rotation = Quaternion.Euler(rotationAngle);
            
        }
        else if (other.gameObject.name == "Enemy"){
            Vector3 vec1 = other.gameObject.GetComponent<EnemyStats>().down;
            Vector3 vec2 = floor.gameObject.GetComponent<Floor>().down;
        }
            
    }
}
