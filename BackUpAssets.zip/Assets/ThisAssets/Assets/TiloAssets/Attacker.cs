using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Attacker : MonoBehaviour
{
    //Init Player Stuff
    GameObject player; 
    PlayerStats stats; 

    //Hitbox
    BoxCollider hitBox;
    
    //Animation stuff
    public Sprite AnimationSprite;
    public SpriteRenderer Swordrenderered;
    public SpriteRenderer Yoyorenderered;

    public Animator animSword;
    public Animator animYoyo;
   


 
    
    //Starting time values. 
    

    // Start is called before the first frame update
    void Start()
    {
        player = this.transform.parent.transform.parent.gameObject;
        stats = player.GetComponent<PlayerStats>();
        hitBox = GetComponent<BoxCollider>();

        hitBox.enabled = false;
    }

    // Update is called once per frame
    void Update()
    {   
        //If the swing is still going, tick down,
        /*if (stats.SwingTime > 0 ){
            stats.SwingTime -= Time.deltaTime;
        } // If its done, then turn off attacks. 
        else{
           this.AttackOff();
        }   */ // If the player is not ready to attack yet, then tick down. 
        if (stats.Initiative > 0 ){
                stats.Initiative -= Time.deltaTime;
        }
        // If they are ready, and they press the fire button, then attack with the current weapon. 
        if(Input.GetButtonDown("Fire1") && stats.Initiative<=0){
                this.Attack(stats.CurrentWeapon);
        }
            
            
    }
    void Attack(Weapon pWeap){
        //Check which weapon is currently being used, and call that weapons function
        if(pWeap.Wname == "Sword"){
            SwordAttack(pWeap);
            Debug.Log("Sword");

        }
        if(pWeap.Wname == "Gun"){
        }
        if(pWeap.Wname == "Yo-yo"){
            YoyoAttack(pWeap);
            Debug.Log("Yoyo");

        }
    }

    void SwordAttack(Weapon pWeap){
        //Change it to red (For testing) and into the diffrent sprite
        Swordrenderered.color = Color.red;
        Swordrenderered.sprite = AnimationSprite; 
        //How long the sword is swinging for. 

        stats.Initiative = pWeap.reloadSpeed;
        Debug.Log("MOnkey");
        //Make it so the sword can hit things, then play the animation that moves it. 
        hitBox.enabled = true;
        animSword.Play("SwordSwing");
        Invoke("AttackOff", 0.5f);

    }
    void YoyoAttack(Weapon pWeap){
        //Change it to red and into the diffrent sprite
        Yoyorenderered.color = Color.red;
        Yoyorenderered.sprite = AnimationSprite; 
        //How long the sword is swinging for. 

        stats.Initiative = pWeap.reloadSpeed;

        //Make it so the yoyo can hit things, then play the animation that moves the yoyo
        hitBox.enabled = true;
        Debug.Log(this.GetComponent<Animator>());
        animYoyo.Play("Yoyo");
        Invoke("AttackOff", 1f);
    }



    void AttackOff(){
        //Turn off the attack, 
        //Hitbox turns off, and has hit turns to true. 
        Yoyorenderered.color = Color.black;
        Swordrenderered.color = Color.black;


        
        hitBox.enabled = false;
        //Bring the renderer back to its original state. 
        animSword.Play("NewState");
        animYoyo.Play("NewState");
        
    }    
    
    
    
    void OnTriggerEnter(Collider collision)
    {
        //If its colliding with the backdrop, ignore it. 
        if(collision.gameObject.name == "Backdrop"){
            return;
        }
        //If it collides with something else, then damage it. 

        if(hitBox.enabled && collision.gameObject.GetComponent<EnemyStats>() != null){
            collision.gameObject.GetComponent<EnemyStats>().Damage(stats.CurrentWeapon.damage);
        }
       
    }

}
