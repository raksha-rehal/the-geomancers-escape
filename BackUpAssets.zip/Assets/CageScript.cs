using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CageScript : MonoBehaviour
{
    public int remainingTrigger; 
    public GameObject myPrefab;
    bool alreadySpawned = false;

    // Start is called before the first frame update


    // Update is called once per frame
    public void removeTrigger()
    {
        remainingTrigger -= 1; 
        if(remainingTrigger <= 0 && !alreadySpawned){
            summonBoss();
        }
        
        

    }
    void summonBoss(){
        Instantiate(myPrefab, this.transform.position, Quaternion.identity);
        alreadySpawned = true;
    }
}
