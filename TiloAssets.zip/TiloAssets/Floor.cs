using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Floor : MonoBehaviour
{
    // Start is called before the first frame update
    public Vector3 down;
    void Start()
    {
        down = this.transform.position - this.transform.GetChild(0).transform.position;
    }

}
