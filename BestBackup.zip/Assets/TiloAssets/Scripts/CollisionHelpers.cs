using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionHelpers : MonoBehaviour
{
    PlayerController playerMovement;
    void Start(){
        playerMovement = GameObject.Find("Player").GetComponent<PlayerController>();
    }
    // Start is called before the first frame update
    void OnTriggerEnter(Collider other){
        if(other.gameObject.tag == "Obsticle"){
             Debug.Log("Trigger IN");
            playerMovement.Mtrigger(transform.name);
        }
       
    } 

    void OnTriggerExit(Collider other){
        if(other.gameObject.tag == "Obsticle"){
             Debug.Log("Trigger Out");
            playerMovement.Mtrigger(transform.name);
        }



    }
}
