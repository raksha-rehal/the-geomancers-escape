using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float moveSpeed;
    public Rigidbody rb;
    private Vector3 moveAxis;
    

    // Update is called once per frame
    void Update()
    {
    
        float maoveX = Input.GetAxisRaw("Horizontal");
        float maoveY = Input.GetAxisRaw("Vertical");

        if (transform.position.x >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on right
        {
            rb.velocity = new Vector3(0, maoveY * moveSpeed, maoveX * moveSpeed);
        }
        else if (transform.position.x <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on left
        {
            rb.velocity = new Vector3(0, maoveY * moveSpeed, -maoveX * moveSpeed);
        }
        else if (transform.position.y >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on top
        {
            rb.velocity = new Vector3(maoveX * moveSpeed, 0, maoveY * moveSpeed);
        }
        else if (transform.position.y <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on bottom
        {
            rb.velocity = new Vector3(maoveX * moveSpeed, 0, -maoveY * moveSpeed);
        }
        else if (transform.position.z >= 10 && -5 <= transform.position.x && transform.position.x <= 5 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on back
        {
            rb.velocity = new Vector3(-maoveX * moveSpeed, maoveY * moveSpeed, 0);
        }
        else if (transform.position.z <= 0 && -5 <= transform.position.y && transform.position.y <= 5 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on front
        {
            rb.velocity = new Vector3(maoveX* moveSpeed, maoveY * moveSpeed,0);
        }
        
    }
}
