using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

// Takes and handles input and movement for a player character
public class PlayerController : MonoBehaviour
{
    public float moveSpeed = 1f;
    public float collisionOffset = 0.05f;
    public ContactFilter2D movementFilter;

    public Vector3 movementInput;
    SpriteRenderer spriteRenderer;
    Rigidbody rb;
    Animator animator;
    List<RaycastHit2D> castCollisions = new List<RaycastHit2D>();
    bool canMove = true;


    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        animator = GetComponent<Animator>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void FixedUpdate() {
        if(canMove) {
            // If movement input is not 0, try to move
            if(movementInput != Vector3.zero){
                bool success = TryMove(movementInput);

                if(!success) {
                    success = TryMove(new Vector3(movementInput.x, 0, 0));
                }

                if(!success) {
                    success = TryMove(new Vector3(0, movementInput.y, 0));
                }
            }

            // Set direction of sprite to movement direction
            animator.SetFloat("Horizontal", movementInput.x);
            animator.SetFloat("Vertical", movementInput.y);
            animator.SetFloat("Speed", movementInput.sqrMagnitude);  
        }
    }

    private bool TryMove(Vector3 direction) {
        if(direction != Vector3.zero) {
            rb.MovePosition(rb.position + direction * moveSpeed * Time.fixedDeltaTime);
            return true;

            // Check for potential collisions
            /*
            int count = rb.Cast(
                direction, // X and Y values between -1 and 1 that represent the direction from the body to look for collisions
                movementFilter, // The settings that determine where a collision can occur on such as layers to collide with
                castCollisions, // List of collisions to store the found collisions into after the Cast is finished
                moveSpeed * Time.fixedDeltaTime + collisionOffset); // The amount to cast equal to the movement plus an offset

            if(count == 0){
            } else {
                return false;
            }
            */
        } else {
            // Can't move if there's no direction to move in
            return false;
        }
        
    }

    void OnMove(InputValue movementValue) {
        movementInput = movementValue.Get<Vector2>();
        movementInput = getDirection(movementInput);
    }
    Vector3 getDirection(Vector3 porl){
        Vector3 Sdirection;
        float xMove = porl.x;
        float yMove = porl.y;
        if (transform.position.x >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on right
        {
             Sdirection = new Vector3(0, yMove * moveSpeed, xMove * moveSpeed);
        }
        else if (transform.position.x <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on left
        {
             Sdirection =new Vector3(0, yMove * moveSpeed, -xMove * moveSpeed);
        }
        else if (transform.position.y >= 5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on top
        {
             Sdirection =new Vector3(xMove * moveSpeed, 0, yMove * moveSpeed);
        }
        else if (transform.position.y <= -5.0 && 0 <= transform.position.z && transform.position.z <= 10 && 
        -5 <= transform.position.x && transform.position.x <= 5)  // movement on bottom
        {
            Sdirection =new Vector3(xMove * moveSpeed, 0, -yMove * moveSpeed);
        }
        else if (transform.position.z >= 10 && -5 <= transform.position.x && transform.position.x <= 5 && 
        -5 <= transform.position.y && transform.position.y <= 5)  // movement on back
        {
             Sdirection = new Vector3(-xMove * moveSpeed, yMove * moveSpeed, 0);
        }
        else /* if (transform.position.z <= 0 && -5 <= transform.position.y && transform.position.y <= 5 && 
        -5 <= transform.position.x && transform.position.x <= 5)*/  // movement on front
        {
             Sdirection = new Vector3(xMove* moveSpeed, yMove * moveSpeed,0);
        }
        return Sdirection;
    }
    
}