using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonScript : MonoBehaviour
{
    CageScript cage;
    bool Triggered = false;
    
    void Start(){
        cage = GameObject.Find("Cage").GetComponent<CageScript>();
    }
    void OnTriggerEnter(Collider other){
        if(other.tag == "Frog" && !Triggered){
            cage.removeTrigger();
        }

    }
}
