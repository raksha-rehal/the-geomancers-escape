using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossFrogScript : EnemyStats
{
    // Start is called before the first frame update
    string Action = "DoubleJump";
    
    void Start(){
        rb = gameObject.GetComponent<Rigidbody>();
        player = GameObject.Find("Player").transform;
        Quaternion startDirection = transform.rotation;


    }

    // Update is called once per frame
    void Update()
    {
        if(isGrounded){
            rb.velocity = new Vector3(0,0,0);
  
        }
        //If 4 is pressed jump, this will evntually get replaced with enemy ai, 
        //but this is the trigger to jump. 
        float distance = Vector3.Distance(player.position, this.gameObject.transform.position);
        if (this.Initiative > 0){
                this.Initiative -= Time.deltaTime;
        }
        else if(distance <= 3.0f){
            if(Action == "DoubleJump"){
                Jump2();
                this.Initiative = 0.5f;
                Action = "Jump";
            }
            else if(Action == "Jump"){
                Jump2();
                this.Initiative = Random.Range(2.0f, 3.0f);
                Action = RandomAction();
            }
            else if(Action == "Attack"){
                this.transform.GetChild(2).GetComponent<Toungue>().Attack();
                this.Initiative = 1f;
                Action = "Stop";
            }
            else if(Action == "Stop"){
                this.transform.GetChild(2).GetComponent<Toungue>().StopSS();
            }
        }

        //Do Gravity if the enemy is not on the ground.  
        if(!isGrounded){
            Gravity();  
            slowDown();
            Quaternion x = Quaternion.LookRotation(down, player.position - this.transform.position);
            this.transform.rotation = x;
        }
    }
    string RandomAction(){
        string[] options = {"Jump","DoubleJump","Attack"};
        string x = options[(int)Random.Range(0.0f, 2.99f)];
        Debug.Log(x);
        return x;
    }


}
