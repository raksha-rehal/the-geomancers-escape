using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyStats : MonoBehaviour
{

    public int Health;
    Rigidbody rb;
    Quaternion lookingDirection;
    //If the enemy is in 2d
    bool isGrounded = true;
    //How much the enemy jumps 
    int jumpforce = 4;
    int gravForce = 2;

    public Vector3 down;



    void Start(){
        rb = gameObject.GetComponent<Rigidbody>();
    }
    void Update()
    {
        if(isGrounded){
            rb.velocity = new Vector3(0,0,0);  
        }
        //If 4 is pressed jump, this will evntually get replaced with enemy ai, 
        //but this is the trigger to jump. 
         if(Input.GetKeyDown("4")){
            Jump2();
         }
        //Do Gravity if the enemy is not on the ground.  
        if(!isGrounded){
            Gravity();  
            slowDown();
        }

    }
    void Gravity(){
        //Add a downward force onto them.
        SetClosestFloor();
        rb.AddForce(down*gravForce);
    }    
    public void Damage(int damage){
        Health -= damage;
        if(Health <=0){
            Death();
        }
    }
    public void Death(){
        //Kill the enemy and destroy all its children
        foreach (Transform child in gameObject.transform) {
            Destroy(child.gameObject);
        }
        Destroy(gameObject);
    }
    
    
    
    void Jump2(){
        //find the distance between the player and the enemy. 
        var direction = (GameObject.Find("Player").transform.position - transform.position);
        Transfer3D();
        //Create the direction he wants to jump, -1 is a placeholder for "up" of the face. 
        Vector3 JDirect = new Vector3(direction.x/6, direction.y/6,direction.z/6);
        JDirect = JDirect - down*2;
        rb.AddForce(JDirect * jumpforce,ForceMode.Impulse);


    }
    void SetClosestFloor(){
        float lowestDistance = 1000;
        GameObject lowest = null;

        foreach(GameObject floor in  GameObject.Find("FloorList").GetComponent<CalculateFloorList>().FloorList){
            float distance = Vector3.Distance(floor.transform.position, this.transform.position);
            
               Debug.Log(distance);
               Debug.Log(lowest);


            if(distance < lowestDistance){
             
                lowest = floor;
                lowestDistance = distance;
            }
        }
        down = lowest.gameObject.GetComponent<Floor>().down;
    }

    void Move(){
        //This code is not used at all lol, but it might be useful for another enemy.
        //Find the distance between the player and the enemy. 
        var direction = (GameObject.Find("Player").transform.position - transform.position).normalized;
        //If the enemy if within 10 units, they start to move 
        if(direction.magnitude <= 10){
            direction.z = 0;
            Vector3 S = direction.normalized;
            //Change Rotation in the direction they are moving.
                if(direction.normalized.x >= 0){
                    lookingDirection = Quaternion.Euler(0,0,270 + 45*direction.normalized.y);
                }

                if(direction.normalized.x <= 0){
                    lookingDirection = Quaternion.Euler(0,0,90 - 45*direction.normalized.y);
                }
                transform.rotation = lookingDirection;
        }
    }

    
    void OnCollisionEnter(Collision monkeyBalls){
        //If its colliding with the backdrop, transfer into 2d. 

        if(monkeyBalls.gameObject.name == "Backdrop"){
            Transfer2D(monkeyBalls);
        }
        if(monkeyBalls.gameObject.tag == "Obsticle"){
            Pause();
        }

    }
    void OnTriggerEnter(Collider monkeyBalls){
        Debug.Log(monkeyBalls.gameObject.name);
        if(monkeyBalls.gameObject.name == "Player"){
            Debug.Log("Player");
            monkeyBalls.gameObject.GetComponent<PlayerStats>().Damage(1);
        }
    }



    void Pause(){
        //Make it get affected by gravity.
        isGrounded = true;
        //Remove all lingering inertia. 
        rb.velocity = new Vector3(0,0,0);
        //Allow it to turn again
        rb.constraints = RigidbodyConstraints.None;
    }

    void Transfer2D(Collision Floor){
        //Make the square invisible and the cuibe visible. 
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = true;
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = false;
        //Make it get affected by gravity.
        isGrounded = true;
        //Remove all lingering inertia. 
        rb.velocity = new Vector3(0,0,0);
        //Allow it to turn again
        this.rb.rotation = Floor.transform.rotation;
        rb.constraints = RigidbodyConstraints.None;

        
    }
    void Transfer3D(){
        //make the square visible and the cube invisible. 
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = false;
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = true;
        //Stop it from getting affected by gravity. 
        isGrounded = false;
        //For the frog, lock the x and y velocity so he jumps in a straight line,
        rb.constraints = RigidbodyConstraints.FreezeRotation;

    }
    void slowDown(){
        //slow down by 5% every frame or so so the movement is less slidey. 
        rb.velocity = Vector3.Scale(rb.velocity, new Vector3(0.999f,0.999f,0.999f));
    }

}



/* 
Jumping Legacy Code. 

    void Jump(){
        this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = true;
        this.transform.GetChild(0).GetComponent<Renderer>().enabled = false;
        StartCoroutine(DoAnimatie());
    }

    IEnumerator DoAnimatie(){
    this.transform.GetChild(1).GetComponent<Animator>().Play("SpiderJump");
    yield return new WaitForSeconds(1f);
    this.transform.GetChild(1).GetComponent<Animator>().Play("NewState");
    this.transform.GetChild(0).GetComponent<Renderer>().enabled = true;
    this.transform.GetChild(1).GetComponent<MeshRenderer>().enabled = false;
    this.transform.position = this.transform.GetChild(1).transform.position;
    this.transform.position = new Vector3(this.transform.position.x,this.transform.position.y,0);
    }
*/